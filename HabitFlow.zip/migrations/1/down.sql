
DROP TABLE habits;
