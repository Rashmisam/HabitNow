
DROP TABLE habit_entries;
